/* Clase para la vista info, sirve para poder ver el tutorial de como funciona
 la aplicación */

package com.example.safedom;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class InfoActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info);

    }
}
