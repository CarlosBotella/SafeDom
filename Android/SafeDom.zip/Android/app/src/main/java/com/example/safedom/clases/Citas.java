package com.example.safedom.clases;

public class Citas {
    private String Fecha;
}
