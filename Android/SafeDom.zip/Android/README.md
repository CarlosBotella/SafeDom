# SafeDom

# Iniciar sesion rol X
# Editar info usuario X
# Agregar foto
# MOSTRAR DATOS SENSORES
# botones atrás X
# medico clicar paciente X
# user admin crear casas X
# familiar? NO
# cambiar about us info para hacer guia
# usuarioactivity para el doctor X
# citas (pedir, recibir, cancelar)
# buscador de pacientes X
# lista SOLO de pacientes X
# boton llamar al paciente X
# abrir mapa con ubicacion de casa paciente (e indicaciones de como llegar?)

